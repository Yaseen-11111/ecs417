
<html lang="en">
<body>
<section id="addBlogPage" class="blog-add-card hide">
	<header>
		<h2>
			Add Blog Post
		</h2>
	</header>
	<section class="blog-content-container row">
		<form id="addEntry">
			<input id="titlePre" name="Title" type="text" placeholder="Title" class="blog-input-box" maxlength="32">
			<textarea id="descPre" name="Description" placeholder="Enter your blog... " class="blog-input-box blog-textarea" ></textarea>
			<button id="preview" type="button" class="button-box submit">Preview</button>
			<button id="clear" type="reset" class="button-box clear">Clear</button>
		</form>
	</section>
</section>
</body>
</html>

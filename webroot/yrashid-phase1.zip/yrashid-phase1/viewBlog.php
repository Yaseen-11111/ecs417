<html>

<body>
<?php

//testing only right now
for ($i = 0; $i <= 10; $i++) {
	echo "<section class='blog-card'>";
	echo 	"<header>";
	echo 		"<h3>TITLE</h3>";
	echo 		"<a>Yaseen Rashid</a><br><br>";
	echo 		"<a>RELEASE_DATE</a>";
	echo 	"</header><hr>";
	echo 	"<section class='content'>";
	echo  		"<p>ijdiasjd saidj said jisad jiodj oiasdj iosd ji sdsai djsad ijasid
					pojasdosa jdposa jdpsja dpjs adp jsdp asjdpasjdojasd jasd oasd
					p sadpoaskd posado asdkjposa dposa jdposaj dopsaj dsadp sjpj sapodjsaodpjaspod
					po awodp asopd saod sapod jsapo dsadj sai djiaosfj sajfosafj sifhusao
					ops dposajdpoisaj dpio jsapodj saopfj fopas j osajfopsa jfposaj fos foj f
					o sapfdo saofpoajsfop saopf ajops jafpoja sfopj faso jsjopfsaopf ofj oaf
					ipoj dsapdkjsoadjsao dosd kjsoapd osadk opsakd osakdoask dosakd osakd oas kdosa
					po sds akopdkasod[ kasodk sao[dksao dks[ oadkaso kd[ sad[a kd[ask ds spdk
				</p>";
	echo 	"</section>";
	echo "</section>";
}
?>
</body>
</html>
